 /**
 * @brief  0.96��0led��ʾ
 * @param	void
 * @retval	void
 * @author ZCD
 * @Time 2021��1��19��
*/
#include "oled096.h"
#include "setjmp.h"
#include "ESP8266.h"

float FrameRate=0;
uint8_t LightTime[2]={0};
uint8_t LightFlag[2]={0xdb,0};

 /**
 * @brief  ��ʾ����1�ı�
 * @param	void
 * @retval	void
 * @author ZCD
 * @Time 2021��1��23��
*/
void text(void)
{
	OLED_ShowChinese(0,0,0,16);//��
	OLED_ShowChinese(16,0,1,16);//��		
	OLED_ShowChinese(32,0,2,16);//��
	OLED_ShowChinese(48,0,3,16);//��
	OLED_ShowChinese(64,0,4,16);//��
	OLED_ShowChinese(80,0,5,16);//��
	OLED_ShowChinese(96,0,6,16);//��
	OLED_ShowChinese(112,0,7,16);//ѧ
	OLED_ShowNum(8,16,2021,4,16);//2121
	OLED_ShowChinese(84,16,8,16);//��
	OLED_ShowChinese(100,16,9,16);//��	
}
 /**
 * @brief  ����У��ͼƬ�ƶ�
 * @param	void
 * @retval	void
 * @author ZCD
 * @Time 2021��1��23��
*/
	uint8_t x=39;
	uint8_t y=18;
	jmp_buf evn;
void XY_Move_test()
{

		if(keyInput[9]==1)
		{
			
			if(y>0)
			{
				y=y-1;
			}
		}
		if(keyInput[11]==1)
		{
			if(y<63)
			{
				y=y+1;
			}
		}
		if(keyInput[14]==1)
		{
			
			if(x>0)
			{
				x=x-1;
			}
		}
		if(keyInput[6]==1)
		{
			if(x<128-45)
			{
				x=x+1;
			}
		}		
		if(keyInput[10]==1)
			{
				longjmp(evn,1);
			}
}
 /**
 * @brief  ���̿����߼�
 * @param	void
 * @retval	void
 * @author ZCD
 * @Time 2021��1��23��
*/
uint8_t Fun1Flag=0;
uint8_t Fun2Flag=1;
uint8_t Fun3Flag=0;
uint8_t LightStamp=0;
void Key_Ctrl(void)
{
	uint8_t X1=8;
	uint8_t X2=24;
	uint8_t X3=24;
	if(keyInput[12]==1)
	{
		Fun1Flag=1;
		Fun2Flag=0;
		Fun3Flag=0;
		LightStamp=0;
	}
	if(keyInput[8]==1)
	{
		Fun1Flag=0;
		Fun2Flag=1;
		Fun3Flag=0;
		LightStamp=0;
	}
	if(keyInput[4]==1)
	{
		if(LightStamp==0)
		{
			for(uint8_t i=0;i<16;i++)
			{keyTrg[i]=0;}
			LightStamp=1;
		}		
		Fun1Flag=0;
		Fun2Flag=0;
		Fun3Flag=1;
	}
	if(Fun1Flag==1)//����1�����֣�
	{
		XY_Move_test();		
		OLED_ShowPicture(x,y,x+45,270,xiaohui);
		text();	
	}
	if(Fun2Flag==1)//����2��ʱ�䣩
	{

		OLED_ShowNum(X1,16,year,4,16);//2121
		OLED_ShowChinese(X1+32,16,10,16);//��
		OLED_ShowNum(X1+48,16,Month,2,16);//01		
		OLED_ShowChinese(X1+64,16,11,16);//��
		OLED_ShowNum(X1+80,16,Day,2,16);//01				
		OLED_ShowChinese(X1+96,16,12,16);//��
		
		OLED_ShowNum(X2,32,Time[0],2,16);//ʱ
		OLED_ShowChinese(X2+16,32,13,16);//:
		OLED_ShowNum(X2+32,32,Time[1],2,16);//��				
		OLED_ShowChinese(X2+48,32,13,16);//:		
		OLED_ShowNum(X2+64,32,Time[2],2,16);//��				
	}
	if(Fun3Flag==1)//����3����ˮ�ƣ�
	{	

		
		OLED_ShowString(X3,16,"L1",16);
		OLED_ShowString(X3+32,16,"L2",16);
		OLED_ShowString(X3+64,16,"L3",16);
		OLED_ShowPicture(X3,40,X3+16,32,LEDLight_OFF);
		OLED_ShowPicture(X3+32,40,X3+48,32,LEDLight_OFF);
		OLED_ShowPicture(X3+64,40,X3+80,32,LEDLight_OFF);	
		if(keyTrg[13]==1)
		{//1s˫����ˮ

			if(LightFlag[0]<0x6)
			{LightFlag[0]=0xdb;}			
			LightFlag[0]=LightFlag[0]>>LightTime[1]/2;
			if((LightFlag[0]&0x1)==1)
			{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
				OLED_ShowPicture(X3,40,X3+16,32,LEDLight_ON);					
			}
			else
			{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
				OLED_ShowPicture(X3,40,X3+16,32,LEDLight_OFF);
			}
			if((LightFlag[0]&0x02)==0x2)
			{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET);
				OLED_ShowPicture(X3+32,40,X3+48,32,LEDLight_ON);				
			}
			else
			{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_SET);
				OLED_ShowPicture(X3+32,40,X3+48,32,LEDLight_OFF);
			}
			if((LightFlag[0]&0x04)==0x4)
			{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);
				OLED_ShowPicture(X3+64,40,X3+80,32,LEDLight_ON);			
			}
			else
			{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);
				OLED_ShowPicture(X3+64,40,X3+80,32,LEDLight_OFF);
			}			
		}
		else if(keyTrg[9]==1)
		{//0.5s����ˮ

			if(LightTime[0]==5||LightTime[0]==10)
			{
				LightFlag[1]++;
			}
			if(LightFlag[1]==1)
			{
				OLED_ShowPicture(X3,40,X3+16,32,LEDLight_ON);
				OLED_ShowPicture(X3+32,40,X3+48,32,LEDLight_OFF);
				OLED_ShowPicture(X3+64,40,X3+80,32,LEDLight_OFF);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13| GPIO_PIN_12, GPIO_PIN_SET);
			}
			if(LightFlag[1]==2)
			{
				OLED_ShowPicture(X3,40,X3+16,32,LEDLight_OFF);
				OLED_ShowPicture(X3+32,40,X3+48,32,LEDLight_ON);
				OLED_ShowPicture(X3+64,40,X3+80,32,LEDLight_OFF);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14| GPIO_PIN_12, GPIO_PIN_SET);				
			}
			if(LightFlag[1]==3)
			{
				OLED_ShowPicture(X3,40,X3+16,32,LEDLight_OFF);
				OLED_ShowPicture(X3+32,40,X3+48,32,LEDLight_OFF);
				OLED_ShowPicture(X3+64,40,X3+80,32,LEDLight_ON);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13| GPIO_PIN_14, GPIO_PIN_SET);				
			}
			if(LightFlag[1]>3)
			{
					LightFlag[1]=1;		
			}
		}
		else
		{//�������Ƶ�

			if(keyTrg[14]==1)
			{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
				OLED_ShowPicture(X3,40,X3+16,32,LEDLight_ON);				
			}
			else
			{
				  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
			}
			if(keyTrg[10]==1)
			{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET);
				OLED_ShowPicture(X3+32,40,X3+48,32,LEDLight_ON);
			}
			else
			{
				  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_SET);
			}
			if(keyTrg[6]==1)
			{
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);

				OLED_ShowPicture(X3+64,40,X3+80,32,LEDLight_ON);
			}
			else
			{
				  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);
			}			
		}
	}
}
uint8_t bright[2]={0x81,0x0f};
void bright_ctrol(void)
{
	if(keyInput[0]==1)
	{
		if(bright[1]<255)
		{
			bright[1]++;
			OLED_ShowNum(0,54,bright[1],3,12);			
		}
		else
		{
			OLED_ShowPicture(0,41,16,32,LEDLight_ON);	
			OLED_ShowNum(0,54,bright[1],3,12);					
		}
		OLED_WR(bright,2,OLED_CMD);
	}
	if(keyInput[1]==1)
	{
		if(bright[1]>0)
		{
			bright[1]--;
			OLED_ShowNum(0,54,bright[1],3,12);			
		}
		else
		{
			OLED_ShowPicture(0,41,16,32,LEDLight_OFF);	
			OLED_ShowNum(0,54,bright[1],3,12);					
		}		
		OLED_WR(bright,2,OLED_CMD);	
	}

}
void SEG_Tag(void)
{
		OLED_GRAM[7][127]=0xff;
		OLED_GRAM[6][0]=0xff;
		OLED_GRAM[5][127]=0xff;
		OLED_GRAM[4][127]=0xff;
		OLED_GRAM[3][0]=0xff;
		OLED_GRAM[2][127]=0xff;
		OLED_GRAM[1][0]=0xff;
		OLED_GRAM[0][127]=0xff;		
}
//����ʵ��
void OLED_Control(void const *argument)
{

	portTickType xLastWakeTime;
	xLastWakeTime = xTaskGetTickCount();

	osDelay(500);	
	OLED_Init();
	OLED_Refresh();
	setjmp(evn);	
//-------------------------------------------------------//	

	x=39;
	y=18;
	for(;;)
	{
		OLED_Clear_Soft();
		
		LightTime[0]++;
		LightTime[1]=LightTime[0]/5;//0.5sʱ���(0-1-2)
		if(LightTime[0]>10)
		{LightTime[0]=0;}	
//-------------------------------------------------------//
		Key_Ctrl();

		for(uint8_t i=0;i<5;i++)
		{
			bright_ctrol();		
		}
//-------------------------------------------------------//		
		//SEG_Tag();
		OLED_Refresh();
		FrameRate=FrameCnt*100;
		FrameCnt=0;
//--------------------------------------------------------------------------------------------------------------------//		
		osDelayUntil(&xLastWakeTime,100/portTICK_RATE_MS);		
  }
}
//���̾��
osThreadId OLED_ControlHandle;
//���̴�������
void OLED_Ctrl_ThreadCreate(osPriority taskPriority)
{
	osThreadDef(OLED_CtrlThread,OLED_Control,taskPriority,0,256);
	OLED_ControlHandle = osThreadCreate(osThread(OLED_CtrlThread),NULL);
}

