#ifndef __BMP_H
#define __BMP_H

#include "stdint.h"
extern const uint8_t xiaohui[270];
extern const uint8_t LEDLight_OFF[32];
extern const uint8_t LEDLight_ON[32];
#endif

